const mongoose = require('mongoose');
const fs = require('fs');
const path = require('path');
// Import the robust SonarCloud service
const codeAnalysisService = require('../Services/RobustSonarCloudService');
const CodeMark = require('../Models/CodeMark');
const Project = require('../Models/Project');
const User = require('../Models/User');

/**
 * Controller for handling code assessments and reviews
 */
exports.submitCode = async (req, res) => {
    let codeAssessment = null;

    try {
        const { projectId } = req.params;
        const userId = req.user.id;

        if (!projectId) {
            return res.status(400).json({
                success: false,
                message: 'Project ID is required'
            });
        }

        // Check if file was uploaded
        if (!req.file) {
            return res.status(400).json({
                success: false,
                message: 'Code file is required'
            });
        }

        // Get project information
        const project = await Project.findById(projectId);
        if (!project) {
            return res.status(404).json({
                success: false,
                message: 'Project not found'
            });
        }

        // Get user information
        const user = await User.findById(userId);
        if (!user) {
            return res.status(404).json({
                success: false,
                message: 'User not found'
            });
        }

        // Generate a unique submission ID
        const submissionId = new mongoose.Types.ObjectId().toString();

        // Get file path
        const filePath = req.file.path;

        // Create initial assessment record before analysis
        // This helps avoid ECONNRESET by responding early
        codeAssessment = new CodeMark({
            project: projectId,
            student: userId,
            submissionId: submissionId,
            fileUrl: filePath,
            fileName: req.file.originalname,
            sonarResults: {},
            sonarProjectKey: `${userId}_${projectId}_${submissionId}`,
            score: 0,  // Will be updated after analysis
            feedback: '',
            status: 'Processing',
            tutorReview: {
                reviewed: false,
                score: null,
                feedback: ''
            },
            createdAt: new Date(),
            updatedAt: new Date()
        });

        // Save initial record
        await codeAssessment.save();

        // Send initial response to client to prevent timeout
        res.status(202).json({
            success: true,
            message: 'Code submitted successfully. Analysis in progress.',
            assessment: {
                id: codeAssessment._id,
                submissionId: submissionId,
                status: 'Processing'
            }
        });

        // Set a timeout to update status if analysis takes too long
        const timeoutId = setTimeout(async () => {
            try {
                const assessment = await CodeMark.findById(codeAssessment._id);
                if (assessment && assessment.status === 'Processing') {
                    console.log(`Analysis timeout for ${submissionId}, updating status to Failed`);
                    assessment.status = 'Failed';
                    assessment.feedback = 'Analysis timed out after 3 minutes';
                    assessment.updatedAt = new Date();
                    await assessment.save();
                }
            } catch (timeoutError) {
                console.error('Error handling analysis timeout:', timeoutError);
            }
        }, 180000); // 3 minutes

        // Now run the analysis asynchronously
        try {
            console.log(`Starting code analysis for submission ${submissionId}...`);
            const analysisResult = await codeAnalysisService.analyzeCode(
                filePath,
                submissionId,
                userId,
                projectId,
                false
            );


            await CodeMark.findByIdAndUpdate(
                codeAssessment._id,
                {
                    sonarResults: analysisResult.analysisResults,
                    sonarProjectKey: analysisResult.projectKey,
                    score: analysisResult.score,
                    detailedScores: analysisResult.detailedScores,
                    status: 'Pending',
                    updatedAt: new Date()
                },
                { new: true }
            );

            console.log(`Analysis completed for submission ${submissionId} with score ${analysisResult.score}`);

        } catch (analysisError) {
            // Clear the timeout since analysis failed
            clearTimeout(timeoutId);

            console.error('Error during code analysis:', analysisError);

            // Update status to Failed if analysis fails
            await CodeMark.findByIdAndUpdate(
                codeAssessment._id,
                {
                    status: 'Failed',
                    feedback: `Analysis failed: ${analysisError.message}`,
                    updatedAt: new Date()
                },
                { new: true }
            );
        }

    } catch (error) {
        console.error('Error submitting code:', error);

        // If we already created a record, update it with error status
        if (codeAssessment) {
            try {
                await CodeMark.findByIdAndUpdate(
                    codeAssessment._id,
                    {
                        status: 'Failed',
                        feedback: `Analysis failed: ${error.message}`,
                        updatedAt: new Date()
                    },
                    { new: true }
                );
            } catch (updateError) {
                console.error('Error updating assessment status:', updateError);
            }
        }

        // If response has not been sent yet, send error response
        if (!res.headersSent) {
            res.status(500).json({
                success: false,
                message: 'Failed to submit code for analysis',
                error: error.message
            });
        }
    }
};

/**
 * Get all assessments for a specific project
 */
exports.getProjectAssessments = async (req, res) => {
    try {
        const { projectId } = req.params;

        if (!projectId) {
            return res.status(400).json({
                success: false,
                message: 'Project ID is required'
            });
        }

        // Find all assessments for the project
        const assessments = await CodeMark.find({ project: projectId })
            .populate('student', 'name lastname email')
            .sort({ createdAt: -1 });

        res.status(200).json({
            success: true,
            count: assessments.length,
            assessments
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: 'Failed to fetch assessments',
            error: error.message
        });
    }
};

/**
 * Add tutor review to a code assessment
 */
exports.tutorReview = async (req, res) => {
    try {
        const { assessmentId } = req.params;
        const { score, feedback } = req.body;
        const tutorId = req.user.id;

        if (!assessmentId) {
            return res.status(400).json({
                success: false,
                message: 'Assessment ID is required'
            });
        }

        if (score === undefined || !feedback) {
            return res.status(400).json({
                success: false,
                message: 'Score and feedback are required'
            });
        }

        // Find the assessment
        const assessment = await CodeMark.findById(assessmentId);
        if (!assessment) {
            return res.status(404).json({
                success: false,
                message: 'Assessment not found'
            });
        }

        // Update with tutor review
        assessment.tutorReview = {
            reviewed: true,
            score: score,
            feedback: feedback,
            tutor: tutorId,
            reviewDate: new Date()
        };

        assessment.status = 'Reviewed';
        assessment.updatedAt = new Date();

        await assessment.save();

        res.status(200).json({
            success: true,
            message: 'Assessment reviewed successfully',
            assessment
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: 'Failed to review assessment',
            error: error.message
        });
    }
};

/**
 * Get assessment details by ID
 */
exports.getAssessmentById = async (req, res) => {
    try {
        const { assessmentId } = req.params;

        if (!assessmentId) {
            return res.status(400).json({
                success: false,
                message: 'Assessment ID is required'
            });
        }

        // Find the assessment
        const assessment = await CodeMark.findById(assessmentId)
            .populate('student', 'name lastname email')
            .populate('project', 'title description');

        if (!assessment) {
            return res.status(404).json({
                success: false,
                message: 'Assessment not found'
            });
        }

        res.status(200).json({
            success: true,
            assessment
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: 'Failed to fetch assessment',
            error: error.message
        });
    }
};

/**
 * Check assessment status
 */
exports.checkAssessmentStatus = async (req, res) => {
    try {
        const { assessmentId } = req.params;

        if (!assessmentId) {
            return res.status(400).json({
                success: false,
                message: 'Assessment ID is required'
            });
        }

        // Find the assessment
        const assessment = await CodeMark.findById(assessmentId);

        if (!assessment) {
            return res.status(404).json({
                success: false,
                message: 'Assessment not found'
            });
        }

        res.status(200).json({
            success: true,
            assessment: {
                id: assessment._id,
                status: assessment.status,
                score: assessment.score,
                submissionId: assessment.submissionId
            }
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: 'Failed to check assessment status',
            error: error.message
        });
    }
};
