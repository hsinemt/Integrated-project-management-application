const fs = require('fs');

/**
 * A simplified code analysis service that doesn't rely on file system scanning
 */
class SimpleCodeAnalyzer {
    /**
     * Analyze a submitted code file
     */
    async analyzeCode(filePath, submissionId, userId, projectId) {
        try {
            console.log(`Starting simple code analysis for submission ${submissionId}`);

            // Read the file content directly
            const fileContent = fs.readFileSync(filePath, 'utf8');

            // Generate a project key
            const projectKey = `${userId}_${projectId}_${submissionId}`;

            // Basic file analysis
            const metrics = this.analyzeFileContent(fileContent);
            const score = this.calculateScore(metrics);

            console.log('Simple analysis completed with score:', score);

            return {
                submissionId,
                projectKey,
                analysisResults: metrics,
                score,
                timestamp: new Date()
            };
        } catch (error) {
            console.error('Error in simple code analysis:', error);
            // Return default results if analysis fails
            return {
                submissionId,
                projectKey: `${userId}_${projectId}_${submissionId}`,
                analysisResults: this.getDefaultMetrics(),
                score: 50, // Default score
                timestamp: new Date()
            };
        }
    }

    /**
     * Analyze file content
     */
    analyzeFileContent(content) {
        // Basic metrics
        const lines = content.split('\n');
        const totalLines = lines.length;

        let commentLines = 0;
        let codeSmells = 0;
        let bugs = 0;

        // Very basic analysis of content
        for (const line of lines) {
            const trimmed = line.trim();

            // Count comments
            if (trimmed.startsWith('//') || trimmed.startsWith('/*') ||
                trimmed.startsWith('*') || trimmed.endsWith('*/')) {
                commentLines++;
            }

            // Count basic code issues
            if (trimmed.includes('TODO') || trimmed.includes('FIXME')) {
                codeSmells++;
            }

            if (trimmed.includes('console.log')) {
                codeSmells++;
            }

            if (trimmed.includes('var ')) {
                codeSmells++;
            }

            if (trimmed.includes('==') && !trimmed.includes('===')) {
                bugs++;
            }
        }

        // Calculate comment density
        const commentDensity = totalLines > 0 ? (commentLines / totalLines) * 100 : 0;

        // Generate ratings
        const reliabilityRating = bugs > 5 ? '3' : bugs > 0 ? '2' : '1';
        const maintainabilityRating = codeSmells > 10 ? '3' : codeSmells > 5 ? '2' : '1';

        return {
            bugs: bugs.toString(),
            vulnerabilities: '0',
            code_smells: codeSmells.toString(),
            coverage: '0',
            duplicated_lines_density: '0',
            reliability_rating: reliabilityRating,
            security_rating: '1',
            sqale_rating: maintainabilityRating,
            complexity: '0',
            ncloc: totalLines.toString(),
            comment_lines_density: commentDensity.toFixed(2)
        };
    }

    /**
     * Get default metrics for when analysis fails
     */
    getDefaultMetrics() {
        return {
            bugs: '0',
            vulnerabilities: '0',
            code_smells: '0',
            coverage: '0',
            duplicated_lines_density: '0',
            reliability_rating: '1',
            security_rating: '1',
            sqale_rating: '1',
            complexity: '0',
            ncloc: '0',
            comment_lines_density: '0'
        };
    }

    /**
     * Calculate score based on metrics
     */
    calculateScore(metrics) {
        // Base score
        let score = 75;

        // Apply adjustments based on metrics
        const bugs = parseInt(metrics.bugs) || 0;
        score -= bugs * 3;

        const codeSmells = parseInt(metrics.code_smells) || 0;
        score -= codeSmells * 0.5;

        const commentDensity = parseFloat(metrics.comment_lines_density) || 0;
        if (commentDensity > 0 && commentDensity <= 40) {
            score += commentDensity * 0.2;
        }

        // Ensure score is between 0 and 100
        return Math.max(0, Math.min(100, Math.round(score)));
    }
}

module.exports = new SimpleCodeAnalyzer();