const sonarqubeScanner = require('sonarqube-scanner').default;
const axios = require('axios');
const fs = require('fs');
const path = require('path');
const unzipper = require('unzipper');
const fse = require('fs-extra');

// Import local analyzer for fallback
const localAnalyzer = require('./SimpleCodeAnalyzer');

// Environment variables
const SONAR_TOKEN = process.env.SONAR_TOKEN || 'e6b6c067e836708894acbe865e5251b12c3447b4';
const SONAR_ORGANIZATION = process.env.SONAR_ORGANIZATION || 'hsinemt';
const SONAR_HOST_URL = process.env.SONAR_HOST_URL || 'https://sonarcloud.io';

// Configuration
const MAX_RETRIES = 3;
const RETRY_DELAY = 1000; // ms
const API_TIMEOUT = 10000; // ms

/**
 * Robust SonarCloud service with error handling and fallback
 */
class RobustSonarCloudService {
    /**
     * Analyze submitted code with SonarCloud
     */
    async analyzeCode(submissionPath, submissionId, userId, projectId, useFallback = false) {
        try {
            console.log(`[${submissionId}] Starting SonarCloud analysis...`);

            // Handle zip files
            const isZip = submissionPath.endsWith('.zip');
            const extractionPath = isZip
                ? path.join(path.dirname(submissionPath), `${submissionId}-extracted`)
                : submissionPath;

            if (isZip) {
                console.log(`[${submissionId}] Extracting zip file...`);
                await this.extractZipFile(submissionPath, extractionPath);
                console.log(`[${submissionId}] Zip extraction complete`);
            }

            // Create a unique project key for SonarCloud
            // Avoid characters that might cause issues in SonarCloud
            const sanitizedUserId = userId.replace(/[^a-zA-Z0-9_]/g, '_');
            const sanitizedProjectId = projectId.replace(/[^a-zA-Z0-9_]/g, '_');
            const sanitizedSubmissionId = submissionId.replace(/[^a-zA-Z0-9_]/g, '_');
            const projectKey = `${sanitizedUserId}_${sanitizedProjectId}_${sanitizedSubmissionId}`;

            console.log(`[${submissionId}] Project key: ${projectKey}`);

            // SonarCloud analysis
            let sonarResults = null;
            let score = 0;
            let detailedScores = null;

            try {
                console.log(`[${submissionId}] Attempting SonarCloud analysis...`);
                // Execute SonarCloud scan with retries
                await this.runSonarScannerWithRetries(extractionPath, projectKey, submissionId);

                // Allow more time for SonarCloud to process the results
                console.log(`[${submissionId}] Waiting for SonarCloud to process results...`);
                await new Promise(resolve => setTimeout(resolve, 10000)); // Increased to 10 seconds

                // Get analysis results with retries
                console.log(`[${submissionId}] Retrieving analysis results...`);
                sonarResults = await this.getSonarAnalysisResultsWithRetries(projectKey);

                // Calculate score with detailed breakdown
                console.log(`[${submissionId}] Calculating score...`);
                const scoreResult = this.calculateScore(sonarResults);
                score = scoreResult.score;
                detailedScores = scoreResult.detailedScores;

                console.log(`[${submissionId}] SonarCloud analysis completed successfully with score ${score}`);
            } catch (sonarError) {
                console.error(`[${submissionId}] SonarCloud analysis failed:`, sonarError);

                if (useFallback) {
                    // Only use fallback if explicitly enabled
                    console.log(`[${submissionId}] Using local analysis fallback...`);
                    const localResults = await localAnalyzer.analyzeCode(
                        submissionPath,
                        submissionId,
                        userId,
                        projectId
                    );

                    sonarResults = localResults.analysisResults;

                    if (localResults.detailedScores) {
                        score = localResults.score;
                        detailedScores = localResults.detailedScores;
                    } else {
                        const scoreResult = this.calculateScore(sonarResults);
                        score = scoreResult.score;
                        detailedScores = scoreResult.detailedScores;
                    }

                    console.log(`[${submissionId}] Local analysis fallback completed with score ${score}`);
                } else {
                    // No fallback - throw the error
                    throw new Error(`SonarCloud analysis failed: ${sonarError.message}`);
                }
            }

            // Clean up extracted files if it was a zip
            if (isZip && fs.existsSync(extractionPath)) {
                console.log(`[${submissionId}] Cleaning up extracted files...`);
                await fse.remove(extractionPath);
                console.log(`[${submissionId}] Cleanup complete`);
            }

            console.log(`[${submissionId}] Analysis process completed successfully`);

            return {
                submissionId,
                projectKey,
                analysisResults: sonarResults,
                score,
                detailedScores,
                timestamp: new Date()
            };
        } catch (error) {
            console.error(`[${submissionId}] Critical error in analysis process:`, error);

            // If we're not using fallback, just throw the error
            if (!useFallback) {
                throw error;
            }

            // Ultimate fallback - return default results
            const defaultMetrics = this.getDefaultMetrics();
            const scoreResult = this.calculateScore(defaultMetrics);

            return {
                submissionId,
                projectKey: `${userId}_${projectId}_${submissionId}`,
                analysisResults: defaultMetrics,
                score: scoreResult.score,
                detailedScores: scoreResult.detailedScores,
                timestamp: new Date()
            };
        }
    }


    /**
     * Extract a zip file to the specified directory
     */
    async extractZipFile(zipFilePath, extractionPath) {
        try {
            // Ensure extraction directory exists
            await fse.ensureDir(extractionPath);

            // Extract zip file
            await fs.createReadStream(zipFilePath)
                .pipe(unzipper.Extract({path: extractionPath}))
                .promise();

            console.log(`Extracted zip file to ${extractionPath}`);
        } catch (error) {
            console.error('Error extracting zip file:', error);
            throw error;
        }
    }

    /**
     * Run SonarQube scanner with retries
     */
    async runSonarScannerWithRetries(sourcePath, projectKey, submissionId) {
        let lastError = null;

        // Try up to MAX_RETRIES times
        for (let attempt = 1; attempt <= MAX_RETRIES; attempt++) {
            try {
                console.log(`[${submissionId}] SonarCloud scan attempt ${attempt}/${MAX_RETRIES}`);

                // Define sources path
                const isDirectory = fs.existsSync(sourcePath) && fs.statSync(sourcePath).isDirectory();
                const sourcesPath = isDirectory ? sourcePath : path.dirname(sourcePath);

                // Setup scanner options
                const options = {
                    serverUrl: SONAR_HOST_URL,
                    token: SONAR_TOKEN,
                    options: {
                        'sonar.organization': SONAR_ORGANIZATION,
                        'sonar.projectKey': projectKey,
                        'sonar.projectName': `Submission-${submissionId}`,
                        'sonar.sources': sourcesPath,
                        'sonar.projectVersion': '1.0.0',
                        'sonar.sourceEncoding': 'UTF-8'
                    }
                };

                // Add single file option if not a directory
                if (!isDirectory) {
                    options.options['sonar.sources'] = path.dirname(sourcePath);
                    options.options['sonar.inclusions'] = path.basename(sourcePath);
                }

                console.log(`[${submissionId}] SonarCloud scanner options:`, JSON.stringify(options, null, 2));

                // Run scanner
                await this.runSonarScanner(options);

                console.log(`[${submissionId}] SonarCloud scan completed successfully`);
                return;
            } catch (error) {
                lastError = error;
                console.error(`[${submissionId}] SonarCloud scan attempt ${attempt} failed:`, error);

                // Wait before retrying
                if (attempt < MAX_RETRIES) {
                    const delay = RETRY_DELAY * attempt;
                    console.log(`[${submissionId}] Waiting ${delay}ms before retry ${attempt + 1}`);
                    await new Promise(resolve => setTimeout(resolve, delay));
                }
            }
        }

        // If we get here, all attempts failed
        throw lastError || new Error(`[${submissionId}] All SonarCloud scan attempts failed`);
    }

    /**
     * Run SonarQube scanner (single attempt)
     */
    async runSonarScanner(options) {
        return new Promise((resolve, reject) => {
            try {
                // Set timeout to avoid hanging
                const timeout = setTimeout(() => {
                    reject(new Error('SonarCloud scanner timed out after 60 seconds'));
                }, 60000); // 60 seconds timeout

                // The function is exported as default export and takes options and a single callback
                sonarqubeScanner(options, (error) => {
                    clearTimeout(timeout);
                    if (error) {
                        console.error('SonarCloud scanner error:', error);
                        reject(error);
                    } else {
                        console.log('SonarCloud scan completed successfully');
                        resolve();
                    }
                });
            } catch (error) {
                reject(error);
            }
        });
    }

    /**
     * Get SonarCloud analysis results with retries
     */
    async getSonarAnalysisResultsWithRetries(projectKey) {
        let lastError = null;

        // Try up to MAX_RETRIES times
        for (let attempt = 1; attempt <= MAX_RETRIES; attempt++) {
            try {
                console.log(`Getting SonarCloud results attempt ${attempt}/${MAX_RETRIES}`);

                // Get results
                const results = await this.getSonarAnalysisResults(projectKey);

                console.log('Retrieved SonarCloud results successfully');
                return results;
            } catch (error) {
                lastError = error;
                console.error(`Getting SonarCloud results attempt ${attempt} failed:`, error);

                // Wait before retrying
                if (attempt < MAX_RETRIES) {
                    const delay = RETRY_DELAY * attempt;
                    console.log(`Waiting ${delay}ms before retry ${attempt + 1}`);
                    await new Promise(resolve => setTimeout(resolve, delay));
                }
            }
        }

        // If we get here, all attempts failed
        throw lastError || new Error('All attempts to get SonarCloud results failed');
    }

    /**
     * Get analysis results from SonarCloud API (single attempt)
     */
    async getSonarAnalysisResults(projectKey) {
        try {
            // Define metrics to retrieve
            const metrics = [
                'bugs', 'vulnerabilities', 'code_smells',
                'coverage', 'duplicated_lines_density',
                'reliability_rating', 'security_rating', 'sqale_rating',
                'complexity', 'ncloc', 'comment_lines_density'
            ].join(',');

            // Call SonarCloud API with timeout
            const response = await axios.get(`${SONAR_HOST_URL}/api/measures/component`, {
                params: {
                    component: projectKey,
                    metricKeys: metrics
                },
                headers: {
                    'Authorization': `Bearer ${SONAR_TOKEN}`
                },
                timeout: API_TIMEOUT
            });

            // Extract measures from response
            const measures = response.data.component.measures;
            const results = {};

            // Convert array of measures to object
            measures.forEach(measure => {
                results[measure.metric] = measure.value;
            });

            return results;
        } catch (error) {
            console.error('Error getting SonarCloud analysis results:', error);
            throw error;
        }
    }

    /**
     * Get default metrics for fallback
     */
    getDefaultMetrics() {
        return {
            bugs: '0',
            vulnerabilities: '0',
            code_smells: '0',
            coverage: '0',
            duplicated_lines_density: '0',
            reliability_rating: '1',
            security_rating: '1',
            sqale_rating: '1',
            complexity: '0',
            ncloc: '0',
            comment_lines_density: '0'
        };
    }

    /**
     * Calculate score based on metrics - starting from 0 and adding points
     */
    calculateScore(metrics) {
        // Start with 0 base score
        let score = 0;

        // Initialize detailed scores object
        const detailedScores = {
            correctnessScore: 0,
            securityScore: 0,
            maintainabilityScore: 0,
            documentationScore: 0,
            cleanCodeScore: 0,
            simplicityScore: 0
        };

        // Convert all metrics to numbers or default to 0
        const bugs = parseInt(metrics.bugs) || 0;
        const vulnerabilities = parseInt(metrics.vulnerabilities) || 0;
        const codeSmells = parseInt(metrics.code_smells) || 0;
        const duplicatedLinesDensity = parseFloat(metrics.duplicated_lines_density) || 0;
        const complexity = parseInt(metrics.complexity) || 0;
        const commentLinesDensity = parseFloat(metrics.comment_lines_density) || 0;
        const totalLines = parseInt(metrics.ncloc) || 0;

        // Get ratings (or default to worst rating)
        const reliabilityRating = parseInt(metrics.reliability_rating) || 5; // 1=A (best) to 5=E (worst)
        const securityRating = parseInt(metrics.security_rating) || 5;
        const maintainabilityRating = parseInt(metrics.sqale_rating) || 5;

        // 1. Correctness (max 30 points) - based on reliability rating and bug count
        const reliabilityScore = Math.max(0, 30 - (bugs * 3));
        const reliabilityMultiplier = (6 - reliabilityRating) / 5; // 1 for A, 0 for E
        detailedScores.correctnessScore = Math.round(reliabilityScore * reliabilityMultiplier);
        score += detailedScores.correctnessScore;

        // 2. Security (max 20 points) - based on security rating and vulnerability count
        const securityScore = Math.max(0, 20 - (vulnerabilities * 4));
        const securityMultiplier = (6 - securityRating) / 5; // 1 for A, 0 for E
        detailedScores.securityScore = Math.round(securityScore * securityMultiplier);
        score += detailedScores.securityScore;

        // 3. Maintainability (max 20 points) - based on maintainability rating and code smells
        const maintainabilityScore = Math.max(0, 20 - (codeSmells * 0.5));
        const maintainabilityMultiplier = (6 - maintainabilityRating) / 5; // 1 for A, 0 for E
        detailedScores.maintainabilityScore = Math.round(maintainabilityScore * maintainabilityMultiplier);
        score += detailedScores.maintainabilityScore;

        // 4. Documentation (max 15 points) - based on comment density
        if (commentLinesDensity <= 40) {
            // Up to 15 points for comment density up to 40%
            detailedScores.documentationScore = Math.round((commentLinesDensity / 40) * 15);
        } else {
            // Penalty for excessive comments (over 40%)
            detailedScores.documentationScore = Math.round(15 - ((commentLinesDensity - 40) / 20) * 5);
        }
        score += detailedScores.documentationScore;

        // 5. Clean code (max 10 points) - based on duplication
        detailedScores.cleanCodeScore = Math.round(Math.max(0, 10 - (duplicatedLinesDensity * 0.5)));
        score += detailedScores.cleanCodeScore;

        // 6. Simplicity (max 5 points) - based on complexity relative to code size
        const complexityRatio = totalLines > 0 ? complexity / totalLines : 0;
        detailedScores.simplicityScore = Math.round(Math.max(0, 5 - (complexityRatio * 50)));
        score += detailedScores.simplicityScore;

        // Ensure score is between 0 and 100 and round to nearest integer
        const totalScore = Math.max(0, Math.min(100, Math.round(score)));

        // Add raw metrics to detailed scores for reference
        detailedScores.rawMetrics = {
            bugs,
            vulnerabilities,
            codeSmells,
            duplicatedLinesDensity,
            complexity,
            commentLinesDensity,
            totalLines,
            reliabilityRating,
            securityRating,
            maintainabilityRating
        };

        // Return both the total score and detailed metrics
        return {
            score: totalScore,
            detailedScores: detailedScores
        };
    }
}

module.exports = new RobustSonarCloudService();
